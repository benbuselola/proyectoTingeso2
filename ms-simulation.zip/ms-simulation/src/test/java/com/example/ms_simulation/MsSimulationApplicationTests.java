package com.example.ms_simulation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSimulationApplicationTests {

	@Test
	void contextLoads() {
	}

}
